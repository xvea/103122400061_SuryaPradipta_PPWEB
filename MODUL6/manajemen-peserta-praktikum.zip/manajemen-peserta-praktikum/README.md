## Cara Menjalankan

1. Instal dependensi:

   ```bash
   pnpm install
   ```

2. Jalankan aplikasi dalam mode development:

   ```bash
   pnpm dev
   ```

3. Buka alamat lokal yang ditampilkan pada terminal, biasanya `http://localhost:5173`.

## Build

Untuk memeriksa dan membangun aplikasi untuk production:

```bash
pnpm build
```

## Catatan

Data peserta disimpan menggunakan React state selama aplikasi berjalan. Memuat ulang halaman akan mengembalikan data ke kondisi awal.
