
import { useState } from "react";
import "./App.css";

import FormPeserta from "./components/FormPeserta";
import FilterPeserta from "./components/FilterPeserta";
import DaftarPeserta from "./components/DaftarPeserta";
import RingkasanPeserta from "./components/RingkasanPeserta";

const DATA_AWAL = [
  {
    id: "m-1",
    nama: "Ani",
    nim: "10121001",
    kelas: "TI-2A",
    hadir: true,
  },
  {
    id: "m-2",
    nama: "Budi",
    nim: "10121002",
    kelas: "TI-2B",
    hadir: false,
  },
  {
    id: "m-3",
    nama: "Citra",
    nim: "10121003",
    kelas: "TI-2A",
    hadir: false,
  },
];

const FORM_AWAL = {
  nama: "",
  nim: "",
  kelas: "",
};

function App() {
  const [peserta, setPeserta] = useState(DATA_AWAL);
  const [form, setForm] = useState(FORM_AWAL);
  const [editId, setEditId] = useState(null);
  const [pencarian, setPencarian] = useState("");
  const [filterKelas, setFilterKelas] = useState("semua");
  const [pesan, setPesan] = useState(null);

  function resetForm() {
    setForm({ ...FORM_AWAL });
    setEditId(null);
    setPesan(null);
  }

  function handleSubmit(event) {
    event.preventDefault();

    const nama = form.nama.trim();
    const nim = form.nim.trim();
    const kelas = form.kelas;

    if (nama.length < 3) {
      setPesan({
        tipe: "error",
        teks: "Nama wajib diisi minimal 3 karakter.",
      });
      return;
    }

    if (!/^\d{8}$/.test(nim)) {
      setPesan({
        tipe: "error",
        teks: "NIM wajib terdiri dari tepat 8 digit angka.",
      });
      return;
    }

    if (!["TI-2A", "TI-2B"].includes(kelas)) {
      setPesan({
        tipe: "error",
        teks: "Silakan pilih kelas TI-2A atau TI-2B.",
      });
      return;
    }

    const nimDuplikat = peserta.some(
      (item) => item.nim === nim && item.id !== editId
    );

    if (nimDuplikat) {
      setPesan({
        tipe: "error",
        teks: "NIM sudah digunakan peserta lain. Gunakan NIM berbeda.",
      });
      return;
    }

    if (editId !== null) {
      setPeserta((sebelumnya) =>
        sebelumnya.map((item) =>
          item.id === editId
            ? { ...item, nama, nim, kelas }
            : item
        )
      );

      resetForm();
      return;
    }

    setPeserta((sebelumnya) => [
      ...sebelumnya,
      {
        id: crypto.randomUUID(),
        nama,
        nim,
        kelas,
        hadir: false,
      },
    ]);

    resetForm();
  }

  function handleEdit(item) {
    setEditId(item.id);
    setForm({
      nama: item.nama,
      nim: item.nim,
      kelas: item.kelas,
    });
    setPesan(null);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function handleBatal() {
    resetForm();
  }

  function handleHapus(id) {
    setPeserta((sebelumnya) =>
      sebelumnya.filter((item) => item.id !== id)
    );

    if (editId === id) {
      resetForm();
    }
  }

  function handleToggleHadir(id) {
    setPeserta((sebelumnya) =>
      sebelumnya.map((item) =>
        item.id === id
          ? { ...item, hadir: !item.hadir }
          : item
      )
    );
  }

  const pesertaTerlihat = peserta.filter((item) => {
    const kataKunci = pencarian.trim().toLowerCase();

    const cocokPencarian =
      item.nama.toLowerCase().includes(kataKunci) ||
      item.nim.toLowerCase().includes(kataKunci);

    const cocokKelas =
      filterKelas === "semua" || item.kelas === filterKelas;

    return cocokPencarian && cocokKelas;
  });

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="PraktikumKu">
          <span className="brand-mark">P</span>
          <span>
            Praktikum<span className="brand-light">Ku</span>
          </span>
        </a>

        <span className="topbar-label">
          SISTEM MANAJEMEN PRAKTIKUM
        </span>
      </header>

      <div className="page-content">
        <section className="hero">
          <div>
            <span className="eyebrow">DASHBOARD</span>
            <h1>Manajemen Peserta</h1>
            <p>
              Kelola data peserta praktikum dan pantau kehadiran
              dalam satu tempat.
            </p>
          </div>

          <div className="hero-decoration" aria-hidden="true">
            <div className="decoration-card">✓</div>
            <div className="decoration-circle" />
          </div>
        </section>

        <RingkasanPeserta
          peserta={peserta}
          jumlahTerlihat={pesertaTerlihat.length}
        />

        <FormPeserta
          form={form}
          setForm={setForm}
          editId={editId}
          pesan={pesan}
          onSubmit={handleSubmit}
          onBatal={handleBatal}
        />

        <section className="panel">
          <div className="list-heading">
            <div>
              <h2>Data Peserta</h2>
              <p>
                Cari dan saring peserta berdasarkan nama, NIM, atau kelas.
              </p>
            </div>
          </div>

          <FilterPeserta
            pencarian={pencarian}
            setPencarian={setPencarian}
            filterKelas={filterKelas}
            setFilterKelas={setFilterKelas}
          />
        </section>

        {peserta.length === 0 ? (
          <section className="panel empty-state">
            <div className="empty-icon">＋</div>
            <h3>Belum ada peserta</h3>
            <p>Tambahkan peserta menggunakan formulir di atas.</p>
          </section>
        ) : (
          <DaftarPeserta
            peserta={pesertaTerlihat}
            onEdit={handleEdit}
            onHapus={handleHapus}
            onToggleHadir={handleToggleHadir}
          />
        )}

        <footer className="footer">
          <span>PraktikumKu</span>
          <span>Modul 06 · React Dasar</span>
        </footer>
      </div>
    </main>
  );
}

export default App;
