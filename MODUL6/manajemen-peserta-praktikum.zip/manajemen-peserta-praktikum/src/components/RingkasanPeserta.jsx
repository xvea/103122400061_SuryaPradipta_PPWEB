
function RingkasanPeserta({ peserta, jumlahTerlihat }) {
  const total = peserta.length;
  const hadir = peserta.filter((item) => item.hadir).length;
  const belumHadir = total - hadir;

  const ringkasan = [
    { label: "Total Peserta", nilai: total, icon: "👥", warna: "blue" },
    { label: "Hadir", nilai: hadir, icon: "✓", warna: "green" },
    { label: "Belum Hadir", nilai: belumHadir, icon: "◷", warna: "orange" },
    { label: "Hasil Ditampilkan", nilai: jumlahTerlihat, icon: "▤", warna: "purple" },
  ];

  return (
    <section className="summary-grid">
      {ringkasan.map((item) => (
        <article className="summary-card" key={item.label}>
          <div className={`summary-icon ${item.warna}`}>{item.icon}</div>
          <div>
            <p className="summary-label">{item.label}</p>
            <h2>{item.nilai}</h2>
          </div>
        </article>
      ))}
    </section>
  );
}

export default RingkasanPeserta;
