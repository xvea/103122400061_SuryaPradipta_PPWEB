
function FilterPeserta({
  pencarian,
  setPencarian,
  filterKelas,
  setFilterKelas,
}) {
  return (
    <div className="filter-bar">
      <div className="search-box">
        <span className="search-icon">⌕</span>
        <input
          type="search"
          placeholder="Cari nama atau NIM..."
          value={pencarian}
          onChange={(event) => setPencarian(event.target.value)}
          aria-label="Cari nama atau NIM peserta"
        />
      </div>

      <div className="filter-select">
        <label htmlFor="filterKelas">Filter kelas</label>
        <select
          id="filterKelas"
          value={filterKelas}
          onChange={(event) => setFilterKelas(event.target.value)}
        >
          <option value="semua">Semua kelas</option>
          <option value="TI-2A">TI-2A</option>
          <option value="TI-2B">TI-2B</option>
        </select>
      </div>
    </div>
  );
}

export default FilterPeserta;
