
function ItemPeserta({
  peserta,
  onEdit,
  onHapus,
  onToggleHadir,
}) {
  return (
    <tr>
      <td>
        <div className="student-name">
          <div className="avatar">
            {peserta.nama.charAt(0).toUpperCase()}
          </div>
          <span>{peserta.nama}</span>
        </div>
      </td>

      <td>
        <span className="nim-text">{peserta.nim}</span>
      </td>

      <td>
        <span className="class-badge">{peserta.kelas}</span>
      </td>

      <td>
        <span
          className={`status-badge ${
            peserta.hadir ? "status-present" : "status-absent"
          }`}
        >
          <span className="status-dot" />
          {peserta.hadir ? "Hadir" : "Belum hadir"}
        </span>
      </td>

      <td>
        <div className="action-buttons">
          <button
            className="btn-icon edit-button"
            type="button"
            onClick={() => onEdit(peserta)}
            aria-label={`Edit ${peserta.nama}`}
            title="Edit peserta"
          >
            ✎
          </button>

          <button
            className="btn-icon attendance-button"
            type="button"
            onClick={() => onToggleHadir(peserta.id)}
            aria-label={`Ubah kehadiran ${peserta.nama}`}
            title={peserta.hadir ? "Batalkan hadir" : "Tandai hadir"}
          >
            {peserta.hadir ? "↶" : "✓"}
          </button>

          <button
            className="btn-icon delete-button"
            type="button"
            onClick={() => onHapus(peserta.id)}
            aria-label={`Hapus ${peserta.nama}`}
            title="Hapus peserta"
          >
            ×
          </button>
        </div>
      </td>
    </tr>
  );
}

export default ItemPeserta;
