
import ItemPeserta from "./ItemPeserta";

function DaftarPeserta({
  peserta,
  onEdit,
  onHapus,
  onToggleHadir,
}) {
  return (
    <section className="panel list-panel">
      <div className="list-heading">
        <div>
          <h2>Daftar Peserta</h2>
          <p>Kelola informasi dan kehadiran peserta praktikum.</p>
        </div>

        <span className="result-count">
          {peserta.length} peserta
        </span>
      </div>

      {peserta.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">⌕</div>
          <h3>Peserta tidak ditemukan</h3>
          <p>
            Tidak ada peserta yang sesuai dengan pencarian atau filter.
          </p>
        </div>
      ) : (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Nama Mahasiswa</th>
                <th>NIM</th>
                <th>Kelas</th>
                <th>Kehadiran</th>
                <th>Aksi</th>
              </tr>
            </thead>

            <tbody>
              {peserta.map((item) => (
                <ItemPeserta
                  key={item.id}
                  peserta={item}
                  onEdit={onEdit}
                  onHapus={onHapus}
                  onToggleHadir={onToggleHadir}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default DaftarPeserta;
