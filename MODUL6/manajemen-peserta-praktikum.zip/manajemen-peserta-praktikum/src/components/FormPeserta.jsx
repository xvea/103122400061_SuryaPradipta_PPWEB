
function FormPeserta({
  form,
  setForm,
  editId,
  pesan,
  onSubmit,
  onBatal,
}) {
  function handleChange(event) {
    const { name, value } = event.target;

    setForm((sebelumnya) => ({
      ...sebelumnya,
      [name]: value,
    }));
  }

  return (
    <section className="panel">
      <div className="panel-heading">
        <div>
          <span className="eyebrow">
            {editId ? "EDIT DATA" : "FORMULIR"}
          </span>
          <h2>{editId ? "Ubah Peserta" : "Tambah Peserta"}</h2>
          <p>
            {editId
              ? "Perbarui informasi peserta praktikum."
              : "Masukkan informasi peserta praktikum baru."}
          </p>
        </div>
        <div className="heading-icon">✎</div>
      </div>

      <form onSubmit={onSubmit} noValidate>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="nama">Nama Mahasiswa</label>
            <input
              id="nama"
              name="nama"
              value={form.nama}
              onChange={handleChange}
              placeholder="Contoh: Dina Putri"
              autoComplete="off"
            />
          </div>

          <div className="field">
            <label htmlFor="nim">NIM</label>
            <input
              id="nim"
              name="nim"
              value={form.nim}
              onChange={handleChange}
              placeholder="8 digit NIM"
              inputMode="numeric"
              maxLength={8}
              autoComplete="off"
            />
          </div>

          <div className="field full-width">
            <label htmlFor="kelas">Kelas Praktikum</label>
            <select
              id="kelas"
              name="kelas"
              value={form.kelas}
              onChange={handleChange}
            >
              <option value="">Pilih kelas</option>
              <option value="TI-2A">TI-2A</option>
              <option value="TI-2B">TI-2B</option>
            </select>
          </div>
        </div>

        {pesan && (
          <div
            className={`message ${
              pesan.tipe === "error"
                ? "message-error"
                : "message-success"
            }`}
            role="alert"
          >
            {pesan.teks}
          </div>
        )}

        <div className="form-actions">
          <button className="btn btn-primary" type="submit">
            {editId ? "Simpan perubahan" : "+ Tambah peserta"}
          </button>

          {editId && (
            <button
              className="btn btn-secondary"
              type="button"
              onClick={onBatal}
            >
              Batal
            </button>
          )}
        </div>
      </form>
    </section>
  );
}

export default FormPeserta;
